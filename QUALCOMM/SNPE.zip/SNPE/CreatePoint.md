## 注册

https://myaccount.qualcomm.com/signup?target=https%3A%2F%2Fdeveloper.qualcomm.com

![image-20230724170355447](images/image-20230724170355447.png)

邮件确认，据实填写。

