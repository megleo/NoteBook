# SNPE

[➡ Part4 Quantization](QUALCOMM/SNPE/04-QuantizeModel.md)

[➡ Part5  UDO](QUALCOMM/SNPE/05-UDO.md)

